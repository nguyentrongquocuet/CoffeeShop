<?php
  session_start();
  header('Content-Type: text/html; charset=UTF-8');
  function show()
  {   
    include 'sql_conn.php';

        $select_product = "SELECT * FROM product GROUP BY id";
              $result = mysqli_query($conn, $select_product);

              if($result->num_rows > 0){
                while($row = mysqli_fetch_assoc($result)){
                $Gia= number_format($row['price'], 0);
                $MoTa = substr($row['species'], 0, 50).'...';
                $Ten = substr($row['name'], 0, 30).'...';
                echo '
                 <meta charset="utf-8">
                 <link rel="stylesheet" href="assets/css/plus_minus.css">
                    <div class="col-md-3">
                        <a data-toggle="modal" data-target="#'.$row['id'].'" class="custom-card">
                          <div class="card mb-4 shadow-sm" style="display: inline-block">
                            <img class="card-img-top" src="'.$row['thumb_img'].'">
                            <div class="card-body">
                              <h5 class="card-title">'.$Ten.'</h5>
                              <p class="card-text" id="currency" style="color: green;">'.$Gia.' đ</p>
                              <div class="d-flex justify-content-between align-items-center">
                                <small class="text-mute" style="color: red;">'.$MoTa.'</small>
                              </div>
                            </div>
                          </div>
                        </a>
                        </div>
                  <div class="modal fade bd-example-modal-xl" id="'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">'.$row['name'].'</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="container-fluid">
                          <div class="row">
                            <div class="col-md-6">
                              <img src="'.$row['thumb_img'].'" alt="'.$row['id'].'" width="500" class="img-fluid" alt="Responsive image">
                            </div>
                            <div class="col-md-6">
                              <h3>'.$row['name'].'</h3>
                              <h5 style="color: green;">'.$Gia.' đ</h5>
                              <h6>Mô tả sản phẩm</h6>
                              <p>'.$row['MoTaHH'].'</p>
                              <form method="post">
                              <div class="def-number-input number-input safari_only">
                <button onclick="this.parentNode.querySelector('."'input[type=number]'"').stepDown()" class="minus" type="button" ></button>
                <input class="quantity" min="0" name="quantity" value="1" type="number">
                <button onclick="this.parentNode.querySelector('."'input[type=number]'"').stepUp()" class="plus" type="button" ></button>
              </div>
                <input type="submit" name="'."add_to_cart".$row['id'].'" class="btn btn-danger" value="Thêm vào giỏ"/>
                <input type="submit" name="'."pay".$row['id'].'" class="btn btn-success" value="Thanh toán"/>
                </form>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                      </div>
                    </div>
                  </div>
                </div>';
              }
            }
          }
?>